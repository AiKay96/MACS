package raft

import (
	"bytes"
	"math"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"6.5840/labgob"
	"6.5840/labrpc"
)

type ApplyMsg struct {
	CommandValid bool
	Command      interface{}
	CommandIndex int

	SnapshotValid bool
	Snapshot      []byte
	SnapshotTerm  int
	SnapshotIndex int
}

type ServerState int

const (
	FOLLOWER ServerState = iota
	CANDIDATE
	LEADER
)

type LogEntry struct {
	Term    int
	Command interface{}
}

// A Go object implementing a single Raft peer.
type Raft struct {
	mu        sync.Mutex
	peers     []*labrpc.ClientEnd
	persister *Persister
	me        int
	dead      int32

	// Persistent all
	currentTerm int
	votedFor    int
	log         []LogEntry

	// Volatile all
	commitIndex int
	lastApplied int

	// Volatile lead
	nextIndex  []int
	matchIndex []int

	// Election
	state           ServerState
	electionTimeout time.Time

	//Snapshot
	prevIndex int
	prevTerm  int

	applyCh chan ApplyMsg
}

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	return rf.currentTerm, rf.state == LEADER
}

// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
// before you've implemented snapshots, you should pass nil as the
// second argument to persister.Save().
// after you've implemented snapshots, pass the current snapshot
// (or nil if there's not yet a snapshot).
func (rf *Raft) persist(snapshot []byte) {
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.currentTerm)
	e.Encode(rf.votedFor)
	e.Encode(rf.log)
	e.Encode(rf.prevIndex)
	e.Encode(rf.prevTerm)
	data := w.Bytes()
	if snapshot == nil {
		snapshot = rf.persister.ReadSnapshot()
	}
	rf.persister.Save(data, snapshot)
}

// restore previously persisted state.
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)
	var currentTerm int
	var votedFor int
	var log []LogEntry
	var prevIndex int
	var prevTerm int
	if d.Decode(&currentTerm) != nil ||
		d.Decode(&votedFor) != nil ||
		d.Decode(&log) != nil ||
		d.Decode(&prevIndex) != nil ||
		d.Decode(&prevTerm) != nil {
		return
	}
	rf.currentTerm = currentTerm
	rf.votedFor = votedFor
	rf.log = log
	rf.prevIndex = prevIndex
	rf.prevTerm = prevTerm
	if prevIndex > rf.commitIndex {
		rf.commitIndex = prevIndex
	}
	if prevIndex > rf.lastApplied {
		rf.lastApplied = prevIndex
	}
}

// the service says it has created a snapshot that has
// all info up to and including index. this means the
// service no longer needs the log through (and including)
// that index. Raft should now trim its log as much as possible.
func (rf *Raft) Snapshot(index int, snapshot []byte) {
	//fmt.Printf("[DEBUG] try to take lock")
	rf.mu.Lock()
	defer rf.mu.Unlock()
	//fmt.Printf("[DEBUG] took lock")
	if index <= rf.prevIndex {
		return
	}

	relativeIndex := index - rf.prevIndex
	if relativeIndex >= len(rf.log) {
		return
	}

	prevTerm := rf.log[relativeIndex].Term
	newLog := make([]LogEntry, 1)
	newLog[0] = LogEntry{Term: prevTerm}
	if relativeIndex < len(rf.log)-1 {
		newLog = append(newLog, rf.log[relativeIndex+1:]...)
	}

	rf.log = newLog
	rf.prevIndex = index
	rf.prevTerm = prevTerm

	rf.persist(snapshot)
}

// example RequestVote RPC arguments structure.
// field names must start with capital letters!
type RequestVoteArgs struct {
	Term         int
	CandidateId  int
	PrevLogIndex int
	PrevLogTerm  int
}

// example RequestVote RPC reply structure.
// field names must start with capital letters!
type RequestVoteReply struct {
	Term        int
	VoteGranted bool
}

type AppendEntriesArgs struct {
	Term         int
	LeaderId     int
	PrevLogIndex int
	PrevLogTerm  int
	Entries      []LogEntry
	LeaderCommit int
}

type AppendEntriesReply struct {
	Term    int
	Success bool
	XTerm   int
	XIndex  int
	XLen    int
}

type InstallSnapshotArgs struct {
	Term      int
	LeaderId  int
	PrevIndex int
	PrevTerm  int
	Data      []byte
}

type InstallSnapshotReply struct {
	Term int
}

// example RequestVote RPC handler.
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist(nil)

	reply.Term = rf.currentTerm
	reply.VoteGranted = false

	if args.Term < rf.currentTerm {
		return
	}

	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.state = FOLLOWER
		rf.votedFor = -1
	}

	prevLogIndex := len(rf.log) - 1
	prevLogTerm := rf.prevTerm
	if prevLogIndex >= 0 {
		prevLogTerm = rf.log[prevLogIndex].Term
	}
	prevLogIndex += rf.prevIndex

	if (rf.votedFor == -1 || rf.votedFor == args.CandidateId) &&
		(args.PrevLogTerm > prevLogTerm ||
			(args.PrevLogTerm == prevLogTerm && args.PrevLogIndex >= prevLogIndex)) {
		reply.VoteGranted = true
		rf.votedFor = args.CandidateId
		rf.resetElectionTimeout()
	}
}

func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	defer rf.persist(nil)

	reply.Term = rf.currentTerm
	reply.Success = false
	reply.XTerm = -1
	reply.XIndex = -1
	reply.XLen = rf.prevIndex + len(rf.log)

	if args.Term < rf.currentTerm {
		return
	}

	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.state = FOLLOWER
		rf.votedFor = -1
	}

	rf.resetElectionTimeout()

	if args.PrevLogIndex < rf.prevIndex || args.PrevLogIndex-rf.prevIndex >= len(rf.log) {
		reply.Success = false
		return
	}

	if args.PrevLogIndex >= rf.prevIndex && rf.log[args.PrevLogIndex-rf.prevIndex].Term != args.PrevLogTerm {
		reply.Success = false
		reply.XTerm = rf.log[args.PrevLogIndex-rf.prevIndex].Term
		for i := args.PrevLogIndex - rf.prevIndex; i >= 0; i-- {
			if rf.log[i].Term == reply.XTerm {
				reply.XIndex = i + rf.prevIndex
			} else if rf.log[i].Term < reply.XTerm {
				break
			}
		}
		return
	}

	if len(args.Entries) > 0 {
		newIndex := args.PrevLogIndex + 1 - rf.prevIndex
		if newIndex < len(rf.log) {
			if rf.log[newIndex].Term != args.Entries[0].Term {
				rf.log = rf.log[:newIndex]
			}
		}

		if newIndex >= len(rf.log) {
			rf.log = append(rf.log, args.Entries...)
		} else {
			for i, entry := range args.Entries {
				if newIndex+i >= len(rf.log) {
					rf.log = append(rf.log, args.Entries[i:]...)
					break
				}
				if rf.log[newIndex+i].Term != entry.Term {
					rf.log = rf.log[:newIndex+i]
					rf.log = append(rf.log, args.Entries[i:]...)
					break
				}
			}
		}
	}

	if args.LeaderCommit > rf.commitIndex {
		lastNewIndex := args.PrevLogIndex + len(args.Entries)
		rf.commitIndex = int(math.Min(float64(args.LeaderCommit), float64(lastNewIndex)))
		go rf.applyCommitted()
	}

	reply.Success = true
}

func (rf *Raft) InstallSnapshot(args *InstallSnapshotArgs, reply *InstallSnapshotReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	reply.Term = rf.currentTerm

	if args.Term < rf.currentTerm {
		return
	}

	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.state = FOLLOWER
		rf.votedFor = -1
	}

	rf.resetElectionTimeout()

	if args.PrevIndex <= rf.prevIndex {
		return
	}

	if args.Data == nil {
		return // Don't install nil snapshots
	}

	newLog := make([]LogEntry, 1)
	newLog[0] = LogEntry{Term: args.PrevTerm}

	if args.PrevIndex < rf.prevIndex+len(rf.log)-1 {
		relativeIndex := args.PrevIndex - rf.prevIndex
		if relativeIndex >= 0 && relativeIndex < len(rf.log) &&
			rf.log[relativeIndex].Term == args.PrevTerm {
			newLog = append(newLog, rf.log[relativeIndex+1:]...)
		}
	}

	rf.log = newLog
	rf.prevIndex = args.PrevIndex
	rf.prevTerm = args.PrevTerm
	if rf.commitIndex < args.PrevIndex {
		rf.commitIndex = args.PrevIndex
	}
	if rf.lastApplied < args.PrevIndex {
		rf.lastApplied = args.PrevIndex
	}
	rf.persist(args.Data)

	msg := ApplyMsg{
		SnapshotValid: true,
		Snapshot:      args.Data,
		SnapshotTerm:  args.PrevTerm,
		SnapshotIndex: args.PrevIndex,
	}
	rf.applyCh <- msg
}

// example code to send a RequestVote RPC to a server.
// server is the index of the target server in rf.peers[].
// expects RPC arguments in args.
// fills in *reply with RPC reply, so caller should
// pass &reply.
// the types of the args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers).
//
// The labrpc package simulates a lossy network, in which servers
// may be unreachable, and in which requests and replies may be lost.
// Call() sends a request and waits for a reply. If a reply arrives
// within a timeout interval, Call() returns true; otherwise
// Call() returns false. Thus Call() may not return for a while.
// A false return can be caused by a dead server, a live server that
// can't be reached, a lost request, or a lost reply.
//
// Call() is guaranteed to return (perhaps after a delay) *except* if the
// handler function on the server side does not return.  Thus there
// is no need to implement your own timeouts around Call().
//
// look at the comments in ../labrpc/labrpc.go for more details.
//
// if you're having trouble getting RPC to work, check that you've
// capitalized all field names in structs passed over RPC, and
// that the caller passes the address of the reply struct with &, not
// the struct itself.
func (rf *Raft) sendRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
	return ok
}

func (rf *Raft) sendAppendEntriesRPC(server int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	ok := rf.peers[server].Call("Raft.AppendEntries", args, reply)
	return ok
}

func (rf *Raft) sendInstallSnapshot(server int) {
	rf.mu.Lock()
	if rf.state != LEADER {
		rf.mu.Unlock()
		return
	}

	snapshot := rf.persister.ReadSnapshot()
	if snapshot == nil || len(snapshot) == 0 {
		rf.mu.Unlock()
		return
	}

	args := InstallSnapshotArgs{
		Term:      rf.currentTerm,
		LeaderId:  rf.me,
		PrevIndex: rf.prevIndex,
		PrevTerm:  rf.prevTerm,
		Data:      snapshot,
	}
	currentTerm := rf.currentTerm
	rf.mu.Unlock()

	reply := InstallSnapshotReply{}
	ok := rf.peers[server].Call("Raft.InstallSnapshot", &args, &reply)
	if !ok {
		return
	}

	rf.mu.Lock()
	defer rf.mu.Unlock()

	if rf.state != LEADER || rf.currentTerm != currentTerm {
		return
	}

	if reply.Term > rf.currentTerm {
		rf.currentTerm = reply.Term
		rf.state = FOLLOWER
		rf.votedFor = -1
		rf.persist(nil)
		return
	}

	rf.matchIndex[server] = args.PrevIndex
	rf.nextIndex[server] = args.PrevIndex + 1
	rf.updateCommitIndex()
}

func (rf *Raft) Start(command interface{}) (int, int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	if rf.state != LEADER {
		return -1, rf.currentTerm, false
	}

	entry := LogEntry{
		Term:    rf.currentTerm,
		Command: command,
	}

	rf.log = append(rf.log, entry)
	rf.matchIndex[rf.me] = rf.prevIndex + len(rf.log) - 1
	rf.nextIndex[rf.me] = rf.prevIndex + len(rf.log)
	rf.persist(nil)

	if len(rf.log) == 1 {
		go rf.sendHeartbeats()
	}

	return rf.prevIndex + len(rf.log) - 1, rf.currentTerm, true
}

func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

func (rf *Raft) resetElectionTimeout() {
	rf.electionTimeout = time.Now().Add(time.Duration(150+rand.Intn(150)) * time.Millisecond)
}

func (rf *Raft) ticker() {
	for rf.killed() == false {
		rf.mu.Lock()
		var electionTime = time.Now().After(rf.electionTimeout) && rf.state != LEADER
		rf.mu.Unlock()

		if electionTime {
			rf.startElection()
		}

		time.Sleep(10 * time.Millisecond)
	}
}

func (rf *Raft) startElection() {
	rf.mu.Lock()
	rf.currentTerm++
	rf.state = CANDIDATE
	rf.votedFor = rf.me
	rf.persist(nil)

	prevLogTerm := rf.prevTerm
	if len(rf.log)-1 >= 0 {
		prevLogTerm = rf.log[len(rf.log)-1].Term
	}
	rf.resetElectionTimeout()

	args := &RequestVoteArgs{
		Term:         rf.currentTerm,
		CandidateId:  rf.me,
		PrevLogIndex: rf.prevIndex + len(rf.log) - 1,
		PrevLogTerm:  prevLogTerm,
	}

	rf.mu.Unlock()

	voteCh := make(chan bool, len(rf.peers))
	for i := range rf.peers {
		if i != rf.me {
			go rf.askVoteReply(i, args, voteCh)
		}
	}

	go rf.countVotes(len(rf.peers)-1, args.Term, voteCh)
}

func (rf *Raft) askVoteReply(peer int, args *RequestVoteArgs, voteCh chan bool) {
	reply := &RequestVoteReply{}

	if rf.sendRequestVote(peer, args, reply) {
		rf.mu.Lock()
		defer rf.mu.Unlock()

		if rf.state != CANDIDATE || rf.currentTerm != args.Term {
			voteCh <- false
			return
		}

		if reply.Term > rf.currentTerm {
			rf.state = FOLLOWER
			rf.currentTerm = reply.Term
			rf.votedFor = -1
			rf.persist(nil)
			rf.resetElectionTimeout()
			voteCh <- false
			return
		}

		voteCh <- reply.VoteGranted
	} else {
		voteCh <- false
	}
}

func (rf *Raft) countVotes(expectedVotes int, term int, voteCh chan bool) {
	votes := 1

	for i := 0; i < expectedVotes; i++ {
		if <-voteCh {
			votes++
			if votes > len(rf.peers)/2 {
				rf.mu.Lock()
				if rf.state == CANDIDATE && rf.currentTerm == term {
					rf.becomeLeader()
				}
				rf.mu.Unlock()
				return
			}
		}
	}
}

func (rf *Raft) becomeLeader() {
	rf.state = LEADER
	rf.nextIndex = make([]int, len(rf.peers))
	rf.matchIndex = make([]int, len(rf.peers))
	for i := range rf.peers {
		rf.nextIndex[i] = rf.prevIndex + len(rf.log)
		rf.matchIndex[i] = 0
	}
	rf.matchIndex[rf.me] = rf.prevIndex + len(rf.log) - 1
	go rf.sendHeartbeats()
}

func (rf *Raft) sendHeartbeats() {
	for rf.killed() == false {
		rf.mu.Lock()
		if rf.state != LEADER {
			rf.mu.Unlock()
			return
		}
		rf.mu.Unlock()

		for i := range rf.peers {
			if i != rf.me {
				go rf.sendHeartbeat(i)
			}
		}

		time.Sleep(100 * time.Millisecond)
	}
}

func (rf *Raft) sendHeartbeat(peer int) {
	rf.mu.Lock()
	if rf.state != LEADER {
		rf.mu.Unlock()
		return
	}

	if rf.nextIndex[peer] <= rf.prevIndex {
		rf.mu.Unlock()
		go rf.sendInstallSnapshot(peer)
		return
	}

	prevLogIndex := rf.nextIndex[peer] - 1
	if prevLogIndex-rf.prevIndex < 0 || prevLogIndex-rf.prevIndex >= len(rf.log) {
		rf.mu.Unlock()
		return
	}
	prevLogTerm := rf.log[prevLogIndex-rf.prevIndex].Term

	entries := make([]LogEntry, len(rf.log[(rf.nextIndex[peer]-rf.prevIndex):]))
	copy(entries, rf.log[(rf.nextIndex[peer]-rf.prevIndex):])

	args := &AppendEntriesArgs{
		Term:         rf.currentTerm,
		LeaderId:     rf.me,
		PrevLogIndex: prevLogIndex,
		PrevLogTerm:  prevLogTerm,
		Entries:      entries,
		LeaderCommit: rf.commitIndex,
	}
	rf.mu.Unlock()

	reply := &AppendEntriesReply{}
	if ok := rf.peers[peer].Call("Raft.AppendEntries", args, reply); ok {
		rf.mu.Lock()
		defer rf.mu.Unlock()

		if reply.Term > rf.currentTerm {
			rf.state = FOLLOWER
			rf.currentTerm = reply.Term
			rf.votedFor = -1
			rf.persist(nil)
			rf.resetElectionTimeout()
			return
		}

		if rf.state != LEADER || args.Term != rf.currentTerm {
			return
		}

		if reply.Success {
			rf.matchIndex[peer] = prevLogIndex + len(entries)
			rf.nextIndex[peer] = rf.matchIndex[peer] + 1
			rf.updateCommitIndex()
		} else {
			if reply.XTerm == -1 {
				rf.nextIndex[peer] = reply.XLen
			} else {
				lastIndex := -1
				for i := len(rf.log) - 1; i >= 0; i-- {
					if rf.log[i].Term == reply.XTerm {
						lastIndex = i + rf.prevIndex
						break
					}
				}
				if lastIndex == -1 {
					rf.nextIndex[peer] = reply.XIndex
				} else {
					rf.nextIndex[peer] = lastIndex + 1
				}
			}
		}
	}
}

func (rf *Raft) updateCommitIndex() {
	for n := rf.prevIndex + len(rf.log) - 1; n > rf.commitIndex; n-- {
		if n <= rf.prevIndex {
			continue
		}
		if rf.log[n-rf.prevIndex].Term == rf.currentTerm {
			count := 1
			for peer := range rf.peers {
				if peer != rf.me && rf.matchIndex[peer] >= n {
					count++
				}
			}
			if count > len(rf.peers)/2 {
				rf.commitIndex = n
				go rf.applyCommitted()
				break
			}
		}
	}
}

func (rf *Raft) applyCommitted() {
	rf.mu.Lock()
	var msgs []ApplyMsg
	for i := rf.lastApplied + 1; i <= rf.commitIndex; i++ {
		if i <= rf.prevIndex || i-rf.prevIndex >= len(rf.log) {
			continue
		}
		msg := ApplyMsg{
			CommandValid: true,
			Command:      rf.log[i-rf.prevIndex].Command,
			CommandIndex: i,
		}
		msgs = append(msgs, msg)
		rf.lastApplied = i
	}
	rf.mu.Unlock()

	for _, msg := range msgs {
		rf.applyCh <- msg
	}
}

func Make(peers []*labrpc.ClientEnd, me int,
	persister *Persister, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.me = me
	rf.applyCh = applyCh

	rf.currentTerm = 0
	rf.votedFor = -1
	rf.log = make([]LogEntry, 0)
	rf.log = append(rf.log, LogEntry{Term: 0})

	rf.prevIndex = 0
	rf.prevTerm = 0
	rf.commitIndex = 0
	rf.lastApplied = 0

	rf.state = FOLLOWER
	rf.nextIndex = make([]int, len(peers))
	rf.matchIndex = make([]int, len(peers))

	rf.readPersist(persister.ReadRaftState())

	snapshot := persister.ReadSnapshot()
	if snapshot != nil && len(snapshot) > 0 {
		msg := ApplyMsg{
			SnapshotValid: true,
			Snapshot:      snapshot,
			SnapshotTerm:  rf.prevTerm,
			SnapshotIndex: rf.prevIndex,
		}
		go func() {
			rf.applyCh <- msg
		}()
	}

	rf.resetElectionTimeout()

	go rf.ticker()

	return rf
}
